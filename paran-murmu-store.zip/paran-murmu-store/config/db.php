<?php
$conn = mysqli_connect("localhost","root","","paran_store");

if(!$conn){
die("Database Failed");
}
?>
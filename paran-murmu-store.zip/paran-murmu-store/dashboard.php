<?php
session_start();

if(!isset($_SESSION['user'])){
header("Location: login.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="dashboard">
<h1>Welcome <?php echo $_SESSION['user']; ?></h1>
<p>Premium User Dashboard</p>
<a href="logout.php">Logout</a>
</div>

</body>
</html>
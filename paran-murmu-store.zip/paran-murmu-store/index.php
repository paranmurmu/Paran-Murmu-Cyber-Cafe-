<?php include 'config/db.php'; ?>
<!DOCTYPE html>
<html>
<head>
<title>Paran Murmu Store</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header>
<div class="logo">
<h1>Paran Murmu Store</h1>
</div>
<nav>
<a href="index.php">Home</a>
<a href="products.php">Products</a>
<a href="login.php">Login</a>
<a href="register.php">Register</a>
</nav>
</header>

<section class="hero">
<h2>Premium eCommerce Website</h2>
<p>Modern Shopping Experience</p>
<a href="products.php" class="btn">Shop Now</a>
</section>
</body>
</html>
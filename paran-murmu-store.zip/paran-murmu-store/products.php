<!DOCTYPE html>
<html>
<head>
<title>Products</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header>
<h1>Products</h1>
</header>

<div class="dashboard">
<p>No products added yet.</p>
</div>

</body>
</html>
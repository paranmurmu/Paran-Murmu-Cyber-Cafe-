# Paran Murmu Store

Premium PHP + MySQL eCommerce Website

## Features
- Login/Register
- Dashboard
- Product Page
- Responsive Design
- GitHub Ready

## Setup
1. Import SQL file
2. Configure db.php
3. Upload to hosting
4. Run project

<?php
session_start();
include 'config/db.php';

if(isset($_POST['login'])){

$email = $_POST['email'];
$password = md5($_POST['password']);

$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";

$result = mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0){

$row = mysqli_fetch_assoc($result);

$_SESSION['user']=$row['name'];

header("Location: dashboard.php");

}else{
echo "Invalid Login";
}
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="form-box">
<h2>User Login</h2>

<form method="POST">
<input type="email" name="email" placeholder="Email">
<input type="password" name="password" placeholder="Password">
<button type="submit" name="login">Login</button>
</form>

</div>
</body>
</html>
<?php
include 'config/db.php';

if(isset($_POST['register'])){

$name=$_POST['name'];
$email=$_POST['email'];
$password=md5($_POST['password']);

$sql="INSERT INTO users(name,email,password)
VALUES('$name','$email','$password')";

mysqli_query($conn,$sql);

echo "Registration Success";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="form-box">
<h2>Create Account</h2>

<form method="POST">
<input type="text" name="name" placeholder="Name">
<input type="email" name="email" placeholder="Email">
<input type="password" name="password" placeholder="Password">
<button type="submit" name="register">Register</button>
</form>

</div>
</body>
</html>